import java.awt.*;
import javax.swing.*;
public class ViewC extends JPanel{
	public ViewC() {
		setBackground(new Color(255,0,255));
	}
}