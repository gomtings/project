
import java.awt.Color;
import javax.swing.*;
public class ViewD extends JPanel{
	public ViewD() {
		setBackground(Color.BLACK);
	}
}
