import java.awt.BorderLayout;
import javax.swing.*;
import javax.swing.text.View;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Alarm_main{
	JFrame f;
	ViewA a;
	ViewB b;
	ViewC c;
	ViewD d;
	
	Alarm_main() {
		f = new JFrame("Alarm_main");
		a = new ViewA();
		b = new ViewB();
		c = new ViewC();
		d = new ViewD();
		a.start();
		b.start();
		JTabbedPane pane = new JTabbedPane();
		pane.add("�˶�", a);
		pane.add("jewelry", b);
		pane.add("?2", c);
		pane.add("?3", d);
		
		f.add(pane);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setBounds(100 , 100 , 500 , 400);
		f.setVisible(true);
		
	}

	public static void main(String[] args) {
		new Alarm_main();
	}
}