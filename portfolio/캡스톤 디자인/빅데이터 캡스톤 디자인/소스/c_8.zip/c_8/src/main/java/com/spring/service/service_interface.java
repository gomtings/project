package com.spring.service;

import java.util.List;

import org.springframework.web.servlet.ModelAndView;

import com.spring.dto.dayInfo_dto;
import com.spring.dto.element_dto;

//import com.spring.dto.dayInfo_dto;

public interface service_interface {
	public List<dayInfo_dto> drawGraph(Object params);
	public List<element_dto> selectEelement(Object params);
	public List<element_dto> monthData(Object params);
	public List<element_dto> dayData(Object params);
	public element_dto realtimeData(Object params);
	public int insertData(element_dto edto);
	public int gpsadd(String x,String y);
}
