package com.spring.dao;

import java.util.List;
import com.spring.dto.dayInfo_dto;
import com.spring.dto.element_dto;

//import com.spring.dto.dayInfo_dto;

public interface dao_interface {
	public List<dayInfo_dto> drawGraph(Object params);
	public List<element_dto> selectEelement(Object params);
	public element_dto realtimeData(Object params);
	public int insertData(Object params);
	public int gpsadd(Object params);
}
