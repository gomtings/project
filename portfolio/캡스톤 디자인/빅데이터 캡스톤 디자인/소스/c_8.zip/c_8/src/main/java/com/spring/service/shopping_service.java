package com.spring.service;

import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.spring.dao.Shopping_Dao;
import com.spring.dto.dayInfo_dto;
//import com.spring.dto.dayInfo_dto;
import com.spring.dto.element_dto;


@Service
public class shopping_service implements service_interface {
	@Autowired
	Shopping_Dao dao;
	List<dayInfo_dto> dayList;
	List<element_dto> eleList;
	element_dto realTimeDto;
	dayInfo_dto addDto;
	
	@Override
	public List<dayInfo_dto> drawGraph(Object params) {
		// TODO Auto-generated method stub
		// ��Ŀ��ġ �������� �޼ҵ�
		dayList=dao.drawGraph(params);
		return dayList;
	}
	@Override
	public List<element_dto> selectEelement(Object params)
	{
		String id = params.toString();
		String[] test=id.split(",");
		String[] test2 = test[1].split(" ");
		try {
			dayInfo_dto d_dto = new dayInfo_dto(1,test[0],test2[1]);
			System.out.println(d_dto.getX()+"x y"+d_dto.getY());
			eleList=dao.selectEelement(d_dto);
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		return eleList;
	}
	@Override
	public List<element_dto> monthData(Object params)
	{
		String id = params.toString();
		String[] test=id.split(",");
		String[] test2 = test[1].split(" ");
		try {
			Calendar oCalendar = Calendar.getInstance( );
			int year= oCalendar.get(Calendar.YEAR);
			int month = (oCalendar.get(Calendar.MONTH) + 1);
			dayInfo_dto d_dto = new dayInfo_dto(1,test[0],test2[1]);
			Map<String,String> map = new HashMap<String, String>();
			map.put("x", d_dto.getX());
			map.put("y", d_dto.getY());
			map.put("year",String.valueOf(year));
			eleList=dao.monthData(map);
			for(element_dto list:eleList)
			{
				System.out.println(list.getDay_());
				System.out.println(list.getElement1());
				System.out.println(list.getElement2());
				System.out.println(list.getElement3());
			}
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		return eleList;
	}
	@Override
	public List<element_dto> dayData(Object params)
	{
		String id = params.toString();
		String[] test=id.split(",");
		String[] test2 = test[1].split(" ");
		try {
			Calendar oCalendar = Calendar.getInstance();
			int year= oCalendar.get(Calendar.YEAR);
			int month = (oCalendar.get(Calendar.MONTH) + 1);
			dayInfo_dto d_dto = new dayInfo_dto(1,test[0],test2[1]);
			Map<String,String> map = new HashMap<String, String>();
			map.put("x", d_dto.getX());
			map.put("y", d_dto.getY());
			map.put("year",String.valueOf(year) );
			map.put("month",String.valueOf(month));
			eleList=dao.dayData(map);
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		return eleList;
	}
	@Override
	public element_dto realtimeData(Object params)
	{
		String id = params.toString();
		String[] test=id.split(",");
		String[] test2 = test[1].split(" ");
		try {
			dayInfo_dto d_dto = new dayInfo_dto(1,test[0],test2[1]);
			System.out.println(d_dto.getX()+"x y"+d_dto.getY());
			realTimeDto=dao.realtimeData(d_dto);
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		return realTimeDto;
	}
	@Override
	public int insertData(element_dto edto)
	{
		int result = -1;
		try {
			result = dao.insertData(edto);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return result;
	}
	@Override
	public int gpsadd(String x,String y)
	{
		addDto=new dayInfo_dto(1,x,y);
		int result=dao.gpsadd(addDto);
		return result;
	}
	
}
