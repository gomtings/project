package com.spring.dto;

public class dayInfo_dto {
	// ��Ŀ�� ������� �ʿ��� dtoŬ����
	private int day_;
	private String x;
	private String y;
	
	public dayInfo_dto()
	{
		
	}
	public dayInfo_dto(int day_,String x,String y)
	{
		this.day_ = day_;
		this.x=x;
		this.y=y;
	}

	public int getDay_() {
		return day_;
	}
	public void setDay_(int day_) {
		this.day_ = day_;
	}
	public String getX() {
		return x;
	}
	public void setX(String x) {
		this.x = x;
	}
	public String getY() {
		return y;
	}
	public void setY(String y) {
		this.y = y;
	}
	
}
