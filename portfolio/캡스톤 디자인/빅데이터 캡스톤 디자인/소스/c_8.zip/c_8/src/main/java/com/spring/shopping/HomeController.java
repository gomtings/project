package com.spring.shopping;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.spring.dto.dayInfo_dto;
import com.spring.dto.element_dto;
import com.spring.service.shopping_service;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	@Autowired
	shopping_service service;
	List<dayInfo_dto> dayDto;
	List<element_dto> eleDto;
	element_dto realTimeDto;
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
	
		return "main";
	}
	@RequestMapping(value = "/equipadd", method = RequestMethod.GET)
	public String equipadd(Locale locale, Model model) {
		
		return "equpadd";
	}
	@RequestMapping(value = "/seeData", method = RequestMethod.GET)
	public String seeData(Locale locale, Model model) {		
		return "map";
	}
	@RequestMapping(value = "/introduce", method = RequestMethod.GET)
	public String introduce(Locale locale, Model model) {		
		return "introduce";
	}
	
	@RequestMapping(value = "/insertdata", method = RequestMethod.GET)
	public String insertdata(HttpServletRequest request,element_dto edto,Model model){
		int result = service.insertData(edto);
		model.addAttribute("x",edto.getX());
		model.addAttribute("y",edto.getY());
		model.addAttribute("element1",edto.getElement1());
		model.addAttribute("element2",edto.getElement2());
		model.addAttribute("element3",edto.getElement3());
		
		return "test";
	}
	
	@RequestMapping(value = "shopping/test", method = RequestMethod.GET)
	public @ResponseBody List<dayInfo_dto> test(HttpServletRequest request,Model model ,@RequestParam("id") String id)
	{
		System.out.println(id);
		dayDto=service.drawGraph(id);
		System.out.println(dayDto);
		
		return dayDto;
	}
	
	@RequestMapping(value = "shopping/selectElement", method = RequestMethod.GET)
	public @ResponseBody List<element_dto> selectElement(HttpServletRequest request,Model model ,@RequestParam("id") String id)
	{
		eleDto=service.selectEelement(id);
		return eleDto;
	}
	@RequestMapping(value = "shopping/monthData", method = RequestMethod.GET)
	public @ResponseBody List<element_dto> monthData(HttpServletRequest request,Model model ,@RequestParam("id") String id)
	{
		eleDto=service.monthData(id);
		return eleDto;
	}
	@RequestMapping(value = "shopping/dayData", method = RequestMethod.GET)
	public @ResponseBody List<element_dto> dayData(HttpServletRequest request,Model model ,@RequestParam("id") String id)
	{
		System.out.println("�������� ����");
		eleDto=service.dayData(id);
		return eleDto;
	}
	@RequestMapping(value = "shopping/realtimeData", method = RequestMethod.GET)
	public @ResponseBody element_dto realtimeData(HttpServletRequest request,Model model ,@RequestParam("id") String id)
	{
		realTimeDto=service.realtimeData(id);
		return realTimeDto;
	}
	@RequestMapping(value = "shopping/gpsadd", method = RequestMethod.GET)
	public @ResponseBody int gpsadd(HttpServletRequest request,@RequestParam("xGPS") String xGPS,@RequestParam("yGPS") String yGPS) {
		System.out.println("����");
		int result=service.gpsadd(xGPS, yGPS);
		return result;
	}
}
