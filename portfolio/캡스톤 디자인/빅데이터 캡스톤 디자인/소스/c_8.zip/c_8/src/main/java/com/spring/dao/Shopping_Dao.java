package com.spring.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.dto.dayInfo_dto;
import com.spring.dto.element_dto;

//import com.spring.dto.dayInfo_dto;

@Repository
public class Shopping_Dao implements dao_interface {
	@Autowired
	SqlSession sqlsession;
 	String namespace="spring.web.mapper.MemberMapper";
 	@Override
	
	public List<dayInfo_dto> drawGraph(Object params)
	{
		//��Ŀ��ġ ������
		return sqlsession.selectList(namespace+".drawDayGraph",params);
	}
	public List<element_dto> selectEelement(Object params)
	{
		return sqlsession.selectList(namespace+".selectElement",params);
	}
	public List<element_dto> monthData(Object params)
	{
		return sqlsession.selectList(namespace+".monthData",params);
	}
	public List<element_dto> dayData(Object params)
	{
		return sqlsession.selectList(namespace+".dayData",params);
	}
	public element_dto realtimeData(Object params)
	{
		return sqlsession.selectOne(namespace+".realTime",params);
	}
	public int insertData(Object params)
	{
		return sqlsession.insert(namespace+".insertData",params);
	}
	public int gpsadd(Object params)
	{
		return sqlsession.insert(namespace+".gpsadd",params);
	}

}
