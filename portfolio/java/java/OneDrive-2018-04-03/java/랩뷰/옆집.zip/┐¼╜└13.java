class Student{
	private String name;
	private int rollno;
	public Student(String na , int rol){
		name = na;
		rollno = rol; 
	}
	public String toString(){
		return "�л��̸� :"+name +" �й� : "+rollno;
	}
}
public class ����13 {
	public static void main (String [] args){
		Student obj = new Student("ȫ�浿" , 202020 );
		System.out.print(obj.toString());
	}

}
