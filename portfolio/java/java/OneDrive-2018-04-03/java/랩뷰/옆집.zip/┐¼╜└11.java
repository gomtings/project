class tangle {
	int w ,h;
	public int area(){
		return w*h;
	}
	public int perimeter(){
		return (w*2)*(h*2);
	}
}
public class ����11 {
	public static void main (String [] args){
		tangle obj = new tangle();
		obj.w=2;
		obj.h=3;
		System.out.print("���� :"+obj.area()+"�ѷ� :"+obj.perimeter());
	}
}
