import java.util.*;
public class no04058 {
	public static void main(String [] args){
		Scanner zz = new Scanner(System.in);
		System.out.print("�� �Է�");
		int a = zz.nextInt();
		for(int z =0;z<=10;z++){
			System.out.println(a+"*"+z+"="+(a*z));
		}
		
	}
}
