public class no0405gugu {
	public static void main(String[] args){
		int a= 1;
		while(a<9){ //
			a++;
			int b=1;
			while(b<9){
				b++;
				System.out.print(a+"*"+b+"="+(a*b) +"\t");
			}
			System.out.println("");
		}
		System.out.println();
	}
}
