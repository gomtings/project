import java.util.*;
public class no04057 {
	public static void main(String [] args){
		Scanner zz = new Scanner(System.in);
		int d=0;
		int x=0;
		System.out.print("���ڸ� �Է� �ϼ���.");
		int z = zz.nextInt();
		for(int a=1; a<=z ;a+=2){
			System.out.print(a);
			//x=a%3;
			//System.out.println(x);
			
		}
			
	}

}
