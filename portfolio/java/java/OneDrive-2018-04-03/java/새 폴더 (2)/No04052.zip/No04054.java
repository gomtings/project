
public class No04054 {
	public static void main(String[] args){
		int i=6;
		while(i<=5){
			System.out.println(i);
			i++;
		}
	int a=6;
		do{
		System.out.println(a);
			a++;
		}while(a<=5);
	}

}
