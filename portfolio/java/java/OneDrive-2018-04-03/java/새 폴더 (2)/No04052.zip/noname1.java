public class noname1 {
	public static void main(String [] args){
		int g=6;
		int d=0;
		int f=0;
		for(int a=0; a<=6; a++){ //��(��)
			for(d=6-a; d>0; d--){//��(���� ���)
					System.out.print("*");
				}
			System.out.println("");
			}
	       for (int v = 0; v < g; v++) {
	            for (int j = 0; j <= v; j++) {
	                System.out.print("*");
	            }
	            System.out.println("");

		}
		}
}


