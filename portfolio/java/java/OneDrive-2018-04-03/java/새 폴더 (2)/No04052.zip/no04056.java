import java.util.*;
public class no04056 {
	public static void main(String [] args){
		Scanner zz = new Scanner(System.in);
		int can =0;
		for(int a =0; a<5; a++){
			System.out.print("0�Է½� ī��Ʈ�� �մϴ�. ");
			int num = zz.nextInt();
			if(num == 0){
				can++;
				continue;
			}
			
		}
	}

}
