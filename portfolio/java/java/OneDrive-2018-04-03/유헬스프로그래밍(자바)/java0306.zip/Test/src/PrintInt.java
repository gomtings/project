
public class PrintInt {
	public static void main(String[] arg) {
		System.out.println(1);
		System.out.println(12);
		System.out.println(123);
		     }
}
