public class PrintDouble {
public static void main(String[]args){
	System.out.println(12.5);
	System.out.println(3.4);
	System.out.println(8.9);
}
}