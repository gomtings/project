public class PrintString {
      public static void main(String[]arg){
             System.out.print(1);
             System.out.print("C++");
             System.out.print("Java" + 10);
             System.out.print("���ϱ�:" + 10 + 10);
             System.out.print("���ϱ�:" + (10 + 10));
          }
}