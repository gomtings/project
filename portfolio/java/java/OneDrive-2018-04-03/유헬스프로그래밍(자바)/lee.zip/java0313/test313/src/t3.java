
public class t3 {
public static void main(String[] args){
		int x =10;
		int y =20;
		int sum;
		sum = x+y ;
		System.out.println("����" + sum);
		System.out.println("Java is simple.");

}
}