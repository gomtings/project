
public class t4 {
	public static void main(String[] args){
		double speed =90.0;
		double time = 60;
		
  System.out.println("speed :" + speed);
  System.out.println("time :" + time);
	}
}
