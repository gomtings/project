package t04;

public class smartphoneTest {
	public static void main(String[] args) {
		phone ph= new smartphone("LG",990000,"LTE",256,true);
		System.out.println(ph);
	}
}
