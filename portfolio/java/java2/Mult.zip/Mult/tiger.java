package animal;
 class tiger extends animal {
 
	int age;
	void move() {
		System.out.println("walk whit 4 feet");
	}
}

