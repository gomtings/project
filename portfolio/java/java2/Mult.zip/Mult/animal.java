package animal;
	abstract class animal {
		String name;
		abstract void move();
}
