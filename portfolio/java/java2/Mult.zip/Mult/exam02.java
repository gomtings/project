package animal;

public class exam02 {
	public static void main(String[] args) {
		tiger tiger1 = new tiger();
		eagle eagle1 = new eagle();
		
		tiger1.move();
		eagle1.move();
	}
}
