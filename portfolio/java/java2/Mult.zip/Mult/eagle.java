package animal;

  class eagle extends animal {
	 String home;
	 void move() {
		 System.out.println("walk this wings");
	 }
}
