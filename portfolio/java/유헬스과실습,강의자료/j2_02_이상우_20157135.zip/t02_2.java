import java.util.Scanner;
public class t02_2 {
	public static void main(String[] args){
	Scanner key = new Scanner(System.in);
	String str;
	int[] count = new int[]{0,0,0,0,0};
	char[] ch = new char[]{'a','b','c','d','e'};
	System.out.println("�ҹ��� ���ڿ��� �Է��� �ּ���.");
	str = key.next();
	for(int i=0; i<str.length();i++){
		for(int j='a'; j<='j';j++){
			if(str.charAt(i) == j){
				count[j-'a']++;
			}
			continue;
		}
	}
	for(int x=0; x<count.length;x++){
		System.out.println(ch[x]+"->count["+x+"]="+count[x]);
	}
	}
}