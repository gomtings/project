class JustFriend { //GirlFriend.java
 char morf;
 String name;
 static int count;
 JustFriend() { this('?', "!"); }; //default constructor
 JustFriend(char morf) { this(morf, "!"); };
 JustFriend(char morf, String n) {this.morf = morf; this.name=n; count++;};
 static int getcount(){
	 return count;
 }
 String getmorf(){
	 if(this.morf =='m'){
		 return "����";
	 }
	 else if(morf == 'f'){
		 return "����";
	 }
	 else{
		 return "??";
	 }
 }
 public String toString(){
	 String rst="";
	 rst+=this.morf + this.name;
	 return rst;
 }
}
public class t00 {
	public static void main(String[] args){
	JustFriend fin = new JustFriend();
	JustFriend fin2 = new JustFriend('m',"�浿��");
	JustFriend fin3 = new JustFriend('f',"����");
	System.out.println("��ü ģ���� ���� : "+JustFriend.count);
	System.out.println(fin );
	System.out.println(fin2);
	System.out.println(fin3);
}
}
