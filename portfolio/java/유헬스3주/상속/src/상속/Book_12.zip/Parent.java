package ���;

public class Parent { 
	Parent() {
        System.out.print("Parent");
    }
} 

