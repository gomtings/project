import java.util.*;
public class �νǼ� {
	public static void main(String [] args){
		Scanner key=new Scanner(System.in);
		System.out.print("�Ǽ� �Է�");
	Double a=key.nextDouble();
	System.out.print("2�Ǽ� �Է�");
	Double b=key.nextDouble();
	Double z=(a>b)?a:b;
	System.out.print(a+"��"+b+"->"+"ū���� "+z);
	}
}
