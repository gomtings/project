
public class ���ﰢ�� {
	public static void main(String [] args){
		int b;
		for(int a=1;a<=5;a++){
			for(b=5-a;b>0;b--){
				System.out.print("*");
			}
			System.out.println ();
		}
		for(int x=1;x<=5;x++){
			for(int c=1;c<=x;c++){
				System.out.print("*");
			}
			System.out.println();
		}
	}

}
