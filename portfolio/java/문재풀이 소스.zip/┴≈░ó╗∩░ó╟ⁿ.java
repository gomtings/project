public class �����ﰢ�� {
	public static void main(String [] args){
		for(int a=0;a<=5;a++){
			for(int b=a;b<5;b++){
				System.out.print(" ");
			}
			for(int c=0;c<a*2-1;c++){
				System.out.print("*");
			}
			System.out.println();
		}
		
		for(int a=5;a>=0;a--){
			for(int b=a;b<5;b++){
				System.out.print(" ");
			}
			for(int c=0;c<a*2-1;c++){
				System.out.print("*");
			}
			System.out.println();
		}
	}
}
