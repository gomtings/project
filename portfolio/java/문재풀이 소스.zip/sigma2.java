public class sigma2 {
	public static void main(String [] args){
		int sum=0;
		for(int a=10;a<=30;a++){
			for(int i=0;i<=5;i++){
			sum+=a*i;
		}
		}
		System.out.print(sum);
	}
}
