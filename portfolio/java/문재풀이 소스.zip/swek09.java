
public class swek09 {
	public static void main(String [] args){
		int d=0;
		int d1=0;
		int sum=0;
		
		while(d<10){
		while(d1<10){
		sum+=d+d1;
		d1++;
		}
		d++;
		d1=0;
		
	}
		System.out.print(sum);
}
}
