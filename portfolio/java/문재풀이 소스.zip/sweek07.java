public class sweek07 {
	public static void main(String [] args){
		int a=3,b=2,c=5;
		if(a>b){
			c++;
		}
		else if(a==b){
			c--;
		}
		else{
			a++;
			b++;
		}
		System.out.print("a"+a+"b"+b+"c"+c);
	}
}
