package game;

public class ShapeTest {
	public static void main(String[] args){
		IDrawable2 [] arrayOfShapes = new IDrawable2 [3];
		arrayOfShapes[0]= new Rectangle();
		arrayOfShapes[1]= new Triangle();
		arrayOfShapes[2]= new Circle();
		arrayOfShapes[0].draw();
		arrayOfShapes[1].draw();
		arrayOfShapes[2].draw();
	}
}
