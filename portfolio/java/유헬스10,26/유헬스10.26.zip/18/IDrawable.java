package game;

 interface IDrawable2 {
	void draw();
}
class Shape implements IDrawable2{
	public void draw(){System.out.println("Shape Draw");}
}
class Rectangle extends Shape implements IDrawable2{
	public void draw(){System.out.println("Shape Draw");}
}

class Triangle extends Shape implements IDrawable2{
	public void draw(){System.out.println("Shape Draw");}
}

class Circle extends Shape implements IDrawable2{
	public void draw(){System.out.println("Shape Draw");}
}
