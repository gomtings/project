package test19;
public class OurClassTest {
	public static Person getMaximum(Person[] array){
		int temp=0;
		for(int i=0;i<array.length;i++){
			if(array[temp].compareTo(array[i])==-1){
				temp=i;
			}
			else {
				
			}
		}
		return array[temp];
	}
	public static void main(String[] args) {
		Person[] p = new Person[3];
		p[0]=new Person("lee",199);
		p[1]=new Person("lee2",100);
		p[2]=new Person("lee3",122);
		for(Person a :p){
			System.out.println(a);
		}
		System.out.print("���� ū Ű :"+getMaximum(p));
		
	}

}
