package test19;

class Person implements IComparable {
private int height;
private String name;
Person(){
	this("",0);
}
Person(String name,int height){
	this.name=name;
	this.height=height;
}
public int getHeight() {
	return height;
}
public void setHeight(int height) {
	this.height = height;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int compareTo(Object other) {
	if ( this.height > ((Person)other).height )
		return 1;
	else if ( this.height == ((Person)other).height )
		return 0;
	else return -1;
}
@Override
public String toString() {
	return "Person : Person [height=" + height + ", name=" + name + "]";
}
}

