package test19;
public interface IComparable {
 int compareTo(Object other); 
}
