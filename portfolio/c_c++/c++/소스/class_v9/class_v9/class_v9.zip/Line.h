#ifndef LINE
#define LINE

class Line : public Shape {
protected:
	virtual void draw();
};

#endif
