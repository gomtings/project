#include <iostream>
#include "Shape.h"
#include "Line.h"
using namespace std;

void Line::draw() {
	cout << "Line" << endl;
}

