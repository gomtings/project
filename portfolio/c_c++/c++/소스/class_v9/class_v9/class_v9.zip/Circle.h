#ifndef CIRCLE
#define CIRCLE

class Circle : public Shape {
protected:
	virtual void draw();
};

#endif
