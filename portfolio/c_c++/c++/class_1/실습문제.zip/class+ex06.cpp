#include<iostream>
/*
int main(void) {
	int list[]{ 2,3,4,5,6 };

	for (int data : list) {
		//std::cout << data << std::endl;
	}
	for (int i = 0; i < 5;i++) {
		std::cout << list[i] << std::endl;
	}

char ch=getchar();
ch = getchar();
}*/