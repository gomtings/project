<? 
       $poll = $_POST[poll];
       
       if ($poll)
       {
           $connect = mysql_connect("localhost", "root", "apmsetup");
           if (!$connect)
               die("DB ���� ���� : " . mysql_error());
           mysql_select_db("test", $connect);
   
           $sql = "update poll set count=count+1 where num=$poll";
           mysql_query($sql, $connect); 
   
           mysql_close($connect); 
       }
       header("Location:poll.php");
   ?>