#include <iostream>
#include <thread>
#include <ctime>
#include <algorithm>

#define true 1
#define false 0
using std::thread;
using namespace std;

void insert(int array[], int size);
void print(int array[], int size);
void bubble(int array[], int size);
unsigned int max_num = 4294967295;
int sample = 0, num2 = 0, index = 0;
int st_index1 = 0, st_index2 = 0, st_index3 = 0;
unsigned long total_time[3];
char a = 'A', yesno = 'n';
bool A = false, B = false, C = false;
/*�ð� ������ ���� �Դϴ�.*/
clock_t start, finish;
double duration;

int i = 0,j = 0,array_size=1000,tp;
int arry[1000];
/**/
void func1() { //3??
	cout << arry[j];
	if (arry[j] > arry[j + 1]) {
		tp = arry[j + 1];
		arry[j + 1] = arry[j];
		arry[j] = tp;
	}
}
void func2() { // 1
	i++;
	if (i < array_size) {
		A = true;
		//cout << j << "???";
	}
}

void func3(int array[], int size) {//2
	for (j = 0; j < array_size; j++) {
		if (arry[j] > arry[j + 1]) {
			tp = arry[j + 1];
			arry[j + 1] = arry[j];
			arry[j] = tp;
			//cout << tp << "\n";
		}
	}
	if (j == array_size - (i + 1)) {
		B = true;
		//cout << j << "+++";
	}
}
int main() {
	insert(arry, array_size);
	print(arry, array_size);
	start = clock();
    while (true) {
        thread t2(func2); //1
		t2.join(); // 1
        thread t3(&func3, arry, array_size);//2
		t3.join(); //2
       // thread t1(func1);//3
        //t1.join();//3

		if (A == true || B == true) {
			break;
		}
    }
	finish = clock();
	duration = (double)(finish - start / CLOCKS_PER_SEC);
	cout << "=============================================================================================\n";
	//print(arry, array_size);
	//cout << "������ �׽�Ʈ ����... �ҿ�ð��� " << (double)(duration / sample) / 1000 << " �� �Դϴ�.\n";
	cout << "������ �׽�Ʈ ����... �ҿ�ð��� " << (double)duration/1000<< " �� �Դϴ�.\n";
	start = clock();
	bubble(arry, array_size);
	finish = clock();
	duration = (double)(finish - start / CLOCKS_PER_SEC);
	print(arry, array_size);
	cout << "bubble  �׽�Ʈ ����... �ҿ�ð��� " << (double)duration / 1000 << " �� �Դϴ�.\n";
}
void insert(int array[],int size) {
	int temp;
	srand((unsigned int)time(0));
	for (int x = 0; x < size; x++) {
		//temp = rand() % 1000;
		array[x]= rand() % size;
	}
}
void print(int array[], int size) {
	cout << "{";
	for (int x = 0; x < size; x++) {
		cout << array[x]<<",";
	}
	cout <<"}\n";
}
void bubble(int array[], int size) {
	for (int i = 0; i < size; i++) {
		for (int j = 0; j < size; j++) {
			if (arry[j] > arry[j + 1]) {
				tp = arry[j + 1];
				arry[j + 1] = arry[j];
				arry[j] = tp;
			}
		}
	}
}