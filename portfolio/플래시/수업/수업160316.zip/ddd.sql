mysql -uroot -papmsetup
show databases;
create database sample;
use sample;
create table friend(
num int NOT NULL,
name char(10),
address char(80),
tel char(20),
PRIMARY KEY(num)
);
alter table friend rename student: 