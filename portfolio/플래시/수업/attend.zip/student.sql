create table student(
stu_no char(10) Not null,
stu_name char(10) Not null,
stu_ename varchar(30),
dept_code int(2) Not null,
grade int(1) Not null,
class int (1) Not null,
juya char(2),
id_num varchar(14) Not null,
post_no varchar(7),
address varchar(100),
tel varchar(14),
phone_no varchar(14),
birth_year char(4),
primary key (stu_no),
constraint s_dp_fk foreign key(dept_code)
references department(dept_code),
constraint s_ps_fk foreign key(post_no)
references post(post_no)
);
