create table post(
post_no varchar(7) Not null,
post_dong char(30) Not null,
post_address char(60) Not null,
ddd char(4),
primary key (post_no)
);