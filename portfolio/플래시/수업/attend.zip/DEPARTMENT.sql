create table department(
dept_code int(2) Not null,
dept_name char(30) Not null,
dept_ename varchar(50),
Create_date date default null,
primary key (dept_code)
);