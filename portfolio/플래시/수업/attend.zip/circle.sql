create table circle(
cir_num int(4) Not null auto_increment,
cir_name char(30) Not null,
stu_no char(10) Not Null,
stu_name char(10) Not Null,
president char(1) default '2' Not null,
primary key (cir_num),
constraint s_ci_fk foreign key(stu_no)
references student(stu_no)
);