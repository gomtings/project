create table professor(
prof_code char(4) Not null,
prof_name char(10) Not null,
prof_ename varchar(30),
Create_date date default null,
primary key (prof_code)
);