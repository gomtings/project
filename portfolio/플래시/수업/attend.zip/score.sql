create table score(
stu_no char(10) Not null,
sco_year char(4) Not null,
sco_term int(1) Not null,
req_point int(2),
take_point int(2),
exam_avg float(2,1),
exam_total int(4),
sco_div char(1),
sco_date date,
primary key (stu_no, sco_year, sco_term)
); 