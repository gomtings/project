create table subject(
sub_code char(5) Not null,
sub_name varchar(50) Not null,
sub_ename varchar(50),
create_year char(4),
primary key (sub_code)
);