create table fee(
stu_no varchar(10) Not null,
fee_year varchar(4) Not null,
fee_term int(1) Not null,
fee_enter int(7),
fee_price int(7) Not null,
fee_total int(7) Default '0' Not null,
jang_code char(2) Null,
jang_total int(7),
fee_pay int(7) Default '0' Not null,
fee_div char(1) Default 'N' Not null,
fee_date date Not null,
primary key (stu_no, fee_year, fee_term)
); 
