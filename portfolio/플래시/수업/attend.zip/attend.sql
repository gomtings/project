create table attend(
stu_no char(10) Not null,
att_year char(4) Not null,
att_term int(1) Not null,
att_isu int(1) Not null,
sub_code char(5) Not null,
prof_code char(4) Not null,
att_point int(1) Not null,
att_grade int(3) default '0',
att_div char(1) default 'N' Not null,
att_jae char(1) default '1',
att_date date Not null,
primary key (stu_no, att_year, att_term, sub_code, prof_code, att_jae),
constraint su_att_fk foreign key(sub_code)
references subject(sub_code),
constraint pr_att_fk foreign key(prof_code)
references professor(prof_code)
); 